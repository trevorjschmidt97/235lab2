#ifndef CR_H
#define CR_H
#include <string>
#include "Course.h"
using std::string;
using std::ostream;

class cr : public Course {
public:
	cr();
	cr(string cName, string cRoom) : Course(cName), courseRoom(cRoom) {};
	string getCourseRoom() { return courseRoom; };
	virtual string toString();
	~cr();

	friend std::ostream& operator<< (ostream& os, cr& me) {
		os << me.toString();
		return os;
	}
	
private: 
	string courseRoom;
};
#endif // CR_H

