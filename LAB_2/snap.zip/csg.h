#ifndef CSG_H
#define CSG_H
#include <string>
#include "Course.h"
#include "Student.h"
using std::string;

class csg : public Course, public Student {
public:
	csg();
	csg(string cName, string stID, string stGrade) : Course(cName), Student(stID), studentGrade(stGrade) {};
	string getGrade() { return studentGrade; };
	virtual string toString();
	~csg();

	friend std::ostream& operator<< (ostream& os, csg& me) {
		os << me.toString();
		return os;
	}

private:
	string studentGrade;
};
#endif // CSG_H
