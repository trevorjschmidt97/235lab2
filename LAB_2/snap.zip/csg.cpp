#include "csg.h"
using std::ostringstream;

csg::csg() {
}

/*toString
@return out.str(), returns the string representation of the class's variables
*/
string csg::toString() {
	ostringstream out;
	out << "csg(" << Course::toString() << "," << Student::toString() << "," << studentGrade << ")";
	return out.str();
}

csg::~csg() {
}