#ifndef STUDENT_H
#define STUDENT_H
#include <sstream>
#include <string>

using std::string;
using std::ostream;

class Student {
public:
	Student();
	Student(string stID);
	string getStudentID() { return studentID; } ;
	virtual string toString();
	~Student();

private:
	string studentID;
};
#endif // STUDENT_H

