#ifndef CDH_H
#define CDH_H
#include <string>
#include "Course.h"
using std::ostringstream;
using std::string;
using std::ostream;

class cdh : public Course {
public:
	cdh();
	cdh(string cName, string cDay, string cTime) : Course(cName), courseDay(cDay), courseTime(cTime) {};
	string getCourseTime() { return courseTime; };
	string getCourseDay() { return courseDay; };
	virtual string toString();
	~cdh();

	friend std::ostream& operator<< (ostream& os, cdh& me) {
		os << me.toString();
		return os;
	}

private:
	string courseDay;
	string courseTime;
};
#endif // CDH_H

