#include "Student.h"

using std::ostringstream;


Student::Student() {
}

Student::Student(string stID) {
	studentID = stID;
}

/*toString
@return out.str(), returns the studentID as a string
*/
string Student::toString() {
	ostringstream out;
	out << studentID;
	return out.str();
}

Student::~Student() {
}
