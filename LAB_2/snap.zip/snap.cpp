#include "snap.h"
using std::ostringstream;

snap::snap() {
}

/*toString
@return out.str(), returns the string representation of the class's variables
*/
string snap::toString() {
	ostringstream out;
	out << "snap(" << Student::toString() << "," << studentName << "," << studentAddress << "," << studentPhone << ")";
	return out.str();
}

/*printInfo
@return out.str(), returns a string of the class variables ordered differently
*/
string snap::printInfo() {
	ostringstream out;
	out << studentName << ", " << getStudentID() << ", " << studentAddress << ", " << studentPhone;
	return out.str();
}

snap::~snap() {
}
