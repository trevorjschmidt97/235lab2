#ifndef COURSE_H
#define COURSE_H
#include <string>
#include <sstream>
using std::string;

class Course {
public:
	Course();
	Course(string cName);
	string getCourseName() { return courseName; };
	virtual string toString();
	~Course();

private:
	string courseName;
};
#endif // COURSE_H
