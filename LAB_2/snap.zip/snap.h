#ifndef SNAP_H
#define SNAP_H
#include <string>
#include "Student.h"
using std::string;
using std::ostream;

class snap : public Student {
public:
	snap();
	snap(string stID, string stName, string stAddress, string stPhone) : Student(stID), studentName(stName), studentAddress(stAddress), studentPhone(stPhone){};
	virtual string toString();
	string getStudentName() { return studentName; };
	string getStudentAddress() { return studentAddress; };
	string getStudentPhone() { return studentPhone; };
	string printInfo();
	~snap();

	friend std::ostream& operator<< (ostream& os, snap& me) {
		os << me.toString();
		return os;
	}

private:
	string studentName;
	string studentAddress;
	string studentPhone;
};
#endif // SNAP_H

