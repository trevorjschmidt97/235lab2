#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include "snap.h"
#include "cdh.h"
#include "cr.h"
#include "csg.h"

using std::string;
using std::ifstream;
using std::ofstream;
using std::cerr;
using std::ostream;
using std::istringstream;
using std::vector;

int main(int argc, char* argv[]) {
	VS_MEM_CHECK

	string studentID;
	string studentName;
	string studentAddress;
	string studentPhone;
	string studentGrade;
	string courseName;
	string courseDay;
	string courseTime;
	string courseRoom;

	vector<snap> snapV;
	vector<csg> csgV;
	vector<cdh> cdhV;
	vector<cr> crV;

	if (argc < 3) {
		cerr << "Need name of input and output files";			
		return 1;
	}

	ifstream in(argv[1]);
	if (!in) {
		cerr << "Failed to open " << argv[1] << " for input";
		return 2;
	}

	ofstream out(argv[2]);
	if (!out) {
		cerr << "Failed to open " << argv[2] << " for output";
		return 3;
	}

	int snapIndex = -1;
	int csgIndex = -1;
	int cdhIndex = -1;
	int crIndex = -1;

	out << "Input Strings: " << std::endl;
	
	for (string line; getline(in, line);) {
		if ("snap(" == line.substr(0, 5)) {
			// snap(studentID,studentName,studentAddress,studentPhone).
			studentID = line.substr(5, line.find(',') - 5);
			line = line.substr(line.find(',') + 1);
			studentName = line.substr(0, line.find(','));
			line = line.substr(line.find(',') + 1);
			studentAddress = line.substr(0, line.find(','));
			line = line.substr(line.find(',') + 1);
			studentPhone = line.substr(0, line.find(')'));
			snapV.push_back(snap(studentID, studentName, studentAddress, studentPhone));
			out << snapV.at(snapIndex + 1) << "." << std::endl;
			snapIndex++;
		}
		else if ("csg(" == line.substr(0, 4)) {
			// csg(courseName,studentID,studentGrade)
			courseName = line.substr(4, line.find(',') - 4);
			line = line.substr(line.find(',') + 1);
			studentID = line.substr(0, line.find(','));
			line = line.substr(line.find(',') + 1);
			studentGrade = line.substr(0, line.find(')'));
			csgV.push_back(csg(courseName, studentID, studentGrade));
			out << csgV.at(csgIndex + 1) << "." << std::endl;
			csgIndex++;
		}
		else if ("cdh(" == line.substr(0, 4)) {
			// cdh(courseName,courseDay,courseTime)
			courseName = line.substr(4, line.find(',') - 4);
			line = line.substr(line.find(',') + 1);
			courseDay = line.substr(0, line.find(','));
			line = line.substr(line.find(',') + 1);
			courseTime = line.substr(0, line.find(')'));
			cdhV.push_back(cdh(courseName, courseDay, courseTime));
			out << cdhV.at(cdhIndex + 1) << "." << std::endl;
			cdhIndex++;
		}
		else if ("cr(" == line.substr(0, 3)) {
			// cr(courseName,courseRoom).
			courseName = line.substr(3, line.find(',') - 3);
			line = line.substr(line.find(',') + 1);
			courseRoom = line.substr(0, line.find(')'));
			crV.push_back(cr(courseName, courseRoom));
			out << crV.at(crIndex + 1) << "." << std::endl;
			crIndex++;
		}
		else {
			out << "**Error: " << line << std::endl;
		}
	}
	in.close();

	out << std::endl << "Vectors: " << std::endl;

	if (snapIndex >= 0) {
		for (int i = 0; i < snapV.size(); i++) {
			out << snapV.at(i) << std::endl;
		}
	}
	if (csgIndex >= 0) {
		for (int i = 0; i < csgV.size(); i++) {
			out << csgV.at(i) << std::endl;
		}
	}
	if (cdhIndex >= 0) {
		for (int i = 0; i < cdhV.size(); i++) {
			out << cdhV.at(i) << std::endl;
		}
	}
	if (crIndex >= 0) {
		for (int i = 0; i < crV.size(); i++) {
			out << crV.at(i) << std::endl;
		}
	}

	out << std::endl << "Course Grades: " << std::endl;

	for (int i = 0; i < csgV.size(); i++) {
		out << csgV.at(i).getCourseName() << ",";
		for (int j = 0; j < snapV.size(); j++) {
			if (snapV.at(j).getStudentID() == csgV.at(i).getStudentID()) {
				out << snapV.at(j).getStudentName() << ",";
			}
		}
		out << csgV.at(i).getGrade() << std::endl;
	}
	out << std::endl;

	out << std::endl << "Student Schedules: " << std::endl;

	for (int i = 0; i < snapV.size(); i++) {
		out << snapV.at(i).printInfo() << std::endl;
		for (int j = 0; j < csgV.size(); j++) {
			if (csgV.at(j).getStudentID() == snapV.at(i).getStudentID()) {
				out << "  " << csgV.at(j).getCourseName() << " ";
				for (int k = 0; k < cdhV.size(); k++) {
					if (csgV.at(j).getCourseName() == cdhV.at(k).getCourseName()) {
						out << cdhV.at(k).getCourseDay();
						courseTime = cdhV.at(k).getCourseTime();
					}
				}
				out << " " << courseTime << ", ";
				for (int h = 0; h < crV.size(); h++) {
					if (csgV.at(j).getCourseName() == crV.at(h).getCourseName()) {
						out << crV.at(h).getCourseRoom();
					}
				}
				out << std::endl;
			}
		}
		out << std::endl;
	}
	
	out.close();

	return 0;
}