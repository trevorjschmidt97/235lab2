#include "Course.h"

using std::ostringstream;

Course::Course() {
}

Course::Course(string cName) {
	courseName = cName;
}

/*toString
@return out.str(), returns the courseName as a string
*/
string Course::toString() {
	ostringstream out;
	out << courseName;
	return out.str();
}

Course::~Course() {
}
