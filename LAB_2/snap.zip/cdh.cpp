#include "cdh.h"
using std::ostringstream;
using std::string;
using std::ostream;

cdh::cdh() {
}

/*toString
@return out.str(), returns the string representation of the class's variables
*/
string cdh::toString() {
	ostringstream out;
	out << "cdh(" << Course::toString() << "," << courseDay << "," << courseTime << ")";
	return out.str();
}

cdh::~cdh() {
}
