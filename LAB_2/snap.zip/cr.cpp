#include "cr.h"

using std::ostringstream;

cr::cr() {
}

/*toString
@return out.str(), returns the string representation of the class's variables
*/
string cr::toString() {
	ostringstream out;
	out << "cr(" << Course::toString() << "," << courseRoom << ")";
	return out.str();
}

cr::~cr() {
}
